--
-- PostgreSQL database dump
--

-- Dumped from database version 15.4 (Debian 15.4-1.pgdg110+1)
-- Dumped by pg_dump version 15.13 (Debian 15.13-1.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.url DROP CONSTRAINT IF EXISTS url_service_id_fkey;
ALTER TABLE IF EXISTS ONLY public.url DROP CONSTRAINT IF EXISTS url_organization_id_fkey;
ALTER TABLE IF EXISTS ONLY public.taxonomy_term DROP CONSTRAINT IF EXISTS taxonomy_term_taxonomy_id_fkey;
ALTER TABLE IF EXISTS ONLY public.service_source DROP CONSTRAINT IF EXISTS service_source_service_id_fkey;
ALTER TABLE IF EXISTS ONLY public.service_source DROP CONSTRAINT IF EXISTS service_source_organization_id_fkey;
ALTER TABLE IF EXISTS ONLY public.service DROP CONSTRAINT IF EXISTS service_program_id_fkey;
ALTER TABLE IF EXISTS ONLY public.service DROP CONSTRAINT IF EXISTS service_organization_id_fkey;
ALTER TABLE IF EXISTS ONLY public.service_capacity DROP CONSTRAINT IF EXISTS service_capacity_unit_id_fkey;
ALTER TABLE IF EXISTS ONLY public.service_capacity DROP CONSTRAINT IF EXISTS service_capacity_service_id_fkey;
ALTER TABLE IF EXISTS ONLY public.service_at_location DROP CONSTRAINT IF EXISTS service_at_location_service_id_fkey;
ALTER TABLE IF EXISTS ONLY public.service_at_location DROP CONSTRAINT IF EXISTS service_at_location_location_id_fkey;
ALTER TABLE IF EXISTS ONLY public.service_area DROP CONSTRAINT IF EXISTS service_area_service_id_fkey;
ALTER TABLE IF EXISTS ONLY public.service_area DROP CONSTRAINT IF EXISTS service_area_service_at_location_id_fkey;
ALTER TABLE IF EXISTS ONLY public.schedule DROP CONSTRAINT IF EXISTS schedule_service_id_fkey;
ALTER TABLE IF EXISTS ONLY public.schedule DROP CONSTRAINT IF EXISTS schedule_service_at_location_id_fkey;
ALTER TABLE IF EXISTS ONLY public.schedule DROP CONSTRAINT IF EXISTS schedule_location_id_fkey;
ALTER TABLE IF EXISTS ONLY public.required_document DROP CONSTRAINT IF EXISTS required_document_service_id_fkey;
ALTER TABLE IF EXISTS ONLY public.program DROP CONSTRAINT IF EXISTS program_organization_id_fkey;
ALTER TABLE IF EXISTS ONLY public.phone DROP CONSTRAINT IF EXISTS phone_service_id_fkey;
ALTER TABLE IF EXISTS ONLY public.phone DROP CONSTRAINT IF EXISTS phone_service_at_location_id_fkey;
ALTER TABLE IF EXISTS ONLY public.phone DROP CONSTRAINT IF EXISTS phone_organization_id_fkey;
ALTER TABLE IF EXISTS ONLY public.phone DROP CONSTRAINT IF EXISTS phone_location_id_fkey;
ALTER TABLE IF EXISTS ONLY public.phone DROP CONSTRAINT IF EXISTS phone_contact_id_fkey;
ALTER TABLE IF EXISTS ONLY public.organization_source DROP CONSTRAINT IF EXISTS organization_source_parent_organization_id_fkey;
ALTER TABLE IF EXISTS ONLY public.organization_source DROP CONSTRAINT IF EXISTS organization_source_organization_id_fkey;
ALTER TABLE IF EXISTS ONLY public.organization_identifier DROP CONSTRAINT IF EXISTS organization_identifier_organization_id_fkey;
ALTER TABLE IF EXISTS ONLY public.location_source DROP CONSTRAINT IF EXISTS location_source_location_id_fkey;
ALTER TABLE IF EXISTS ONLY public.location DROP CONSTRAINT IF EXISTS location_organization_id_fkey;
ALTER TABLE IF EXISTS ONLY public.language DROP CONSTRAINT IF EXISTS language_service_id_fkey;
ALTER TABLE IF EXISTS ONLY public.language DROP CONSTRAINT IF EXISTS language_phone_id_fkey;
ALTER TABLE IF EXISTS ONLY public.language DROP CONSTRAINT IF EXISTS language_location_id_fkey;
ALTER TABLE IF EXISTS ONLY public.funding DROP CONSTRAINT IF EXISTS funding_service_id_fkey;
ALTER TABLE IF EXISTS ONLY public.funding DROP CONSTRAINT IF EXISTS funding_organization_id_fkey;
ALTER TABLE IF EXISTS ONLY public.cost_option DROP CONSTRAINT IF EXISTS cost_option_service_id_fkey;
ALTER TABLE IF EXISTS ONLY public.contact DROP CONSTRAINT IF EXISTS contact_service_id_fkey;
ALTER TABLE IF EXISTS ONLY public.contact DROP CONSTRAINT IF EXISTS contact_service_at_location_id_fkey;
ALTER TABLE IF EXISTS ONLY public.contact DROP CONSTRAINT IF EXISTS contact_organization_id_fkey;
ALTER TABLE IF EXISTS ONLY public.contact DROP CONSTRAINT IF EXISTS contact_location_id_fkey;
ALTER TABLE IF EXISTS ONLY public.attribute DROP CONSTRAINT IF EXISTS attribute_taxonomy_term_id_fkey;
ALTER TABLE IF EXISTS ONLY public.address DROP CONSTRAINT IF EXISTS address_location_id_fkey;
ALTER TABLE IF EXISTS ONLY public.accessibility DROP CONSTRAINT IF EXISTS accessibility_location_id_fkey;
DROP TRIGGER IF EXISTS update_canonical_location_trigger ON public.location_source;
DROP TRIGGER IF EXISTS organization_normalize_name_trigger ON public.organization;
DROP INDEX IF EXISTS public.service_source_service_scraper_idx;
DROP INDEX IF EXISTS public.service_source_service_id_idx;
DROP INDEX IF EXISTS public.service_source_scraper_id_idx;
DROP INDEX IF EXISTS public.service_organization_id_idx;
DROP INDEX IF EXISTS public.service_name_organization_idx;
DROP INDEX IF EXISTS public.record_version_source_id_idx;
DROP INDEX IF EXISTS public.reconciler_violations_resolved_idx;
DROP INDEX IF EXISTS public.reconciler_violations_created_at_idx;
DROP INDEX IF EXISTS public.organization_source_scraper_id_idx;
DROP INDEX IF EXISTS public.organization_source_organization_id_idx;
DROP INDEX IF EXISTS public.organization_source_org_scraper_idx;
DROP INDEX IF EXISTS public.organization_normalized_name_idx;
DROP INDEX IF EXISTS public.location_source_scraper_id_idx;
DROP INDEX IF EXISTS public.location_source_location_scraper_idx;
DROP INDEX IF EXISTS public.location_source_location_id_idx;
DROP INDEX IF EXISTS public.location_coordinates_idx;
DROP INDEX IF EXISTS public.idx_record_version_type;
DROP INDEX IF EXISTS public.idx_record_version_record;
DROP INDEX IF EXISTS public.idx_record_version_created;
DROP INDEX IF EXISTS public.idx_location_coords;
ALTER TABLE IF EXISTS ONLY public.url DROP CONSTRAINT IF EXISTS url_pkey;
ALTER TABLE IF EXISTS ONLY public.unit DROP CONSTRAINT IF EXISTS unit_pkey;
ALTER TABLE IF EXISTS ONLY public.taxonomy_term DROP CONSTRAINT IF EXISTS taxonomy_term_pkey;
ALTER TABLE IF EXISTS ONLY public.taxonomy_term DROP CONSTRAINT IF EXISTS taxonomy_term_code_key;
ALTER TABLE IF EXISTS ONLY public.taxonomy DROP CONSTRAINT IF EXISTS taxonomy_pkey;
ALTER TABLE IF EXISTS ONLY public.service_source DROP CONSTRAINT IF EXISTS service_source_service_id_scraper_id_key;
ALTER TABLE IF EXISTS ONLY public.service_source DROP CONSTRAINT IF EXISTS service_source_pkey;
ALTER TABLE IF EXISTS ONLY public.service DROP CONSTRAINT IF EXISTS service_pkey;
ALTER TABLE IF EXISTS ONLY public.service DROP CONSTRAINT IF EXISTS service_name_organization_unique;
ALTER TABLE IF EXISTS ONLY public.service_capacity DROP CONSTRAINT IF EXISTS service_capacity_pkey;
ALTER TABLE IF EXISTS ONLY public.service_at_location DROP CONSTRAINT IF EXISTS service_at_location_pkey;
ALTER TABLE IF EXISTS ONLY public.service_area DROP CONSTRAINT IF EXISTS service_area_pkey;
ALTER TABLE IF EXISTS ONLY public.schedule DROP CONSTRAINT IF EXISTS schedule_pkey;
ALTER TABLE IF EXISTS ONLY public.required_document DROP CONSTRAINT IF EXISTS required_document_pkey;
ALTER TABLE IF EXISTS ONLY public.record_version DROP CONSTRAINT IF EXISTS record_version_record_id_version_num_key;
ALTER TABLE IF EXISTS ONLY public.record_version DROP CONSTRAINT IF EXISTS record_version_pkey;
ALTER TABLE IF EXISTS ONLY public.reconciler_constraint_violations DROP CONSTRAINT IF EXISTS reconciler_constraint_violations_pkey;
ALTER TABLE IF EXISTS ONLY public.reconciler_config DROP CONSTRAINT IF EXISTS reconciler_config_pkey;
ALTER TABLE IF EXISTS ONLY public.program DROP CONSTRAINT IF EXISTS program_pkey;
ALTER TABLE IF EXISTS ONLY public.program DROP CONSTRAINT IF EXISTS program_organization_id_key;
ALTER TABLE IF EXISTS ONLY public.phone DROP CONSTRAINT IF EXISTS phone_pkey;
ALTER TABLE IF EXISTS ONLY public.organization_source DROP CONSTRAINT IF EXISTS organization_source_pkey;
ALTER TABLE IF EXISTS ONLY public.organization_source DROP CONSTRAINT IF EXISTS organization_source_organization_id_scraper_id_key;
ALTER TABLE IF EXISTS ONLY public.organization DROP CONSTRAINT IF EXISTS organization_pkey;
ALTER TABLE IF EXISTS ONLY public.organization DROP CONSTRAINT IF EXISTS organization_normalized_name_unique;
ALTER TABLE IF EXISTS ONLY public.organization_identifier DROP CONSTRAINT IF EXISTS organization_identifier_pkey;
ALTER TABLE IF EXISTS ONLY public.metadata DROP CONSTRAINT IF EXISTS metadata_pkey;
ALTER TABLE IF EXISTS ONLY public.meta_table_description DROP CONSTRAINT IF EXISTS meta_table_description_pkey;
ALTER TABLE IF EXISTS ONLY public.location_source DROP CONSTRAINT IF EXISTS location_source_pkey;
ALTER TABLE IF EXISTS ONLY public.location_source DROP CONSTRAINT IF EXISTS location_source_location_id_scraper_id_key;
ALTER TABLE IF EXISTS ONLY public.location DROP CONSTRAINT IF EXISTS location_pkey;
ALTER TABLE IF EXISTS ONLY public.language DROP CONSTRAINT IF EXISTS language_pkey;
ALTER TABLE IF EXISTS ONLY public.funding DROP CONSTRAINT IF EXISTS funding_pkey;
ALTER TABLE IF EXISTS ONLY public.cost_option DROP CONSTRAINT IF EXISTS cost_option_pkey;
ALTER TABLE IF EXISTS ONLY public.contact DROP CONSTRAINT IF EXISTS contact_pkey;
ALTER TABLE IF EXISTS ONLY public.attribute DROP CONSTRAINT IF EXISTS attribute_pkey;
ALTER TABLE IF EXISTS ONLY public.address DROP CONSTRAINT IF EXISTS address_pkey;
ALTER TABLE IF EXISTS ONLY public.accessibility DROP CONSTRAINT IF EXISTS accessibility_pkey;
ALTER TABLE IF EXISTS public.reconciler_constraint_violations ALTER COLUMN id DROP DEFAULT;
DROP TABLE IF EXISTS public.url;
DROP TABLE IF EXISTS public.unit;
DROP TABLE IF EXISTS public.taxonomy_term;
DROP TABLE IF EXISTS public.taxonomy;
DROP TABLE IF EXISTS public.service_source;
DROP TABLE IF EXISTS public.service_capacity;
DROP TABLE IF EXISTS public.service_at_location;
DROP TABLE IF EXISTS public.service_area;
DROP TABLE IF EXISTS public.service;
DROP TABLE IF EXISTS public.schedule;
DROP TABLE IF EXISTS public.required_document;
DROP TABLE IF EXISTS public.record_version;
DROP SEQUENCE IF EXISTS public.reconciler_constraint_violations_id_seq;
DROP TABLE IF EXISTS public.reconciler_constraint_violations;
DROP TABLE IF EXISTS public.reconciler_config;
DROP TABLE IF EXISTS public.program;
DROP TABLE IF EXISTS public.phone;
DROP TABLE IF EXISTS public.organization_source;
DROP TABLE IF EXISTS public.organization_identifier;
DROP TABLE IF EXISTS public.organization;
DROP TABLE IF EXISTS public.metadata;
DROP TABLE IF EXISTS public.meta_table_description;
DROP VIEW IF EXISTS public.location_merged_view;
DROP TABLE IF EXISTS public.location_source;
DROP TABLE IF EXISTS public.location;
DROP TABLE IF EXISTS public.language;
DROP TABLE IF EXISTS public.funding;
DROP TABLE IF EXISTS public.cost_option;
DROP TABLE IF EXISTS public.contact;
DROP TABLE IF EXISTS public.attribute;
DROP TABLE IF EXISTS public.address;
DROP TABLE IF EXISTS public.accessibility;
DROP FUNCTION IF EXISTS public.update_organization_normalized_name();
DROP FUNCTION IF EXISTS public.update_canonical_location();
DROP FUNCTION IF EXISTS public.release_organization_lock(lock_id bigint);
DROP FUNCTION IF EXISTS public.release_location_lock(lock_id bigint);
DROP FUNCTION IF EXISTS public.normalize_organization_name(name text);
DROP FUNCTION IF EXISTS public.location_coordinates_match(lat1 numeric, lon1 numeric, lat2 numeric, lon2 numeric, tolerance numeric);
DROP FUNCTION IF EXISTS public.get_version_history(p_record_id uuid, p_record_type text);
DROP FUNCTION IF EXISTS public.get_latest_version(p_record_id uuid, p_record_type text);
DROP FUNCTION IF EXISTS public.cleanup_old_constraint_violations(retention_days integer);
DROP FUNCTION IF EXISTS public.acquire_organization_lock(org_name text);
DROP FUNCTION IF EXISTS public.acquire_location_lock(lat numeric, lon numeric);
DROP TYPE IF EXISTS public.service_status_enum;
DROP TYPE IF EXISTS public.schedule_wkst_enum;
DROP TYPE IF EXISTS public.schedule_freq_enum;
DROP TYPE IF EXISTS public.location_location_type_enum;
DROP TYPE IF EXISTS public.address_address_type_enum;
DROP EXTENSION IF EXISTS "uuid-ossp";
DROP EXTENSION IF EXISTS postgis;
--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: address_address_type_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.address_address_type_enum AS ENUM (
    'physical',
    'postal',
    'virtual'
);


--
-- Name: location_location_type_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.location_location_type_enum AS ENUM (
    'physical',
    'postal',
    'virtual'
);


--
-- Name: schedule_freq_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.schedule_freq_enum AS ENUM (
    'WEEKLY',
    'MONTHLY'
);


--
-- Name: schedule_wkst_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.schedule_wkst_enum AS ENUM (
    'MO',
    'TU',
    'WE',
    'TH',
    'FR',
    'SA',
    'SU'
);


--
-- Name: service_status_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.service_status_enum AS ENUM (
    'active',
    'inactive',
    'defunct',
    'temporarily closed'
);


--
-- Name: acquire_location_lock(numeric, numeric); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.acquire_location_lock(lat numeric, lon numeric) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
    lock_id BIGINT;
    coord_hash TEXT;
BEGIN
    -- Create deterministic lock ID from coordinates (rounded to tolerance)
    coord_hash := ROUND(lat, 4)::TEXT || ',' || ROUND(lon, 4)::TEXT;
    lock_id := abs(hashtext(coord_hash));
    PERFORM pg_advisory_lock(lock_id);
    RETURN lock_id;
END;
$$;


--
-- Name: acquire_organization_lock(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.acquire_organization_lock(org_name text) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
    lock_id BIGINT;
BEGIN
    -- Create deterministic lock ID from normalized organization name
    lock_id := abs(hashtext(normalize_organization_name(org_name)));
    PERFORM pg_advisory_lock(lock_id);
    RETURN lock_id;
END;
$$;


--
-- Name: cleanup_old_constraint_violations(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.cleanup_old_constraint_violations(retention_days integer DEFAULT 30) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    deleted_count INTEGER;
BEGIN
    DELETE FROM reconciler_constraint_violations
    WHERE created_at < NOW() - INTERVAL '1 day' * retention_days
    AND resolved = TRUE;

    GET DIAGNOSTICS deleted_count = ROW_COUNT;
    RETURN deleted_count;
END;
$$;


--
-- Name: FUNCTION cleanup_old_constraint_violations(retention_days integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.cleanup_old_constraint_violations(retention_days integer) IS 'Cleans up resolved constraint violations older than specified days. Call periodically from application.';


--
-- Name: get_latest_version(uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_latest_version(p_record_id uuid, p_record_type text) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$ BEGIN RETURN (
        SELECT data
        FROM record_version
        WHERE record_id = p_record_id
            AND record_type = p_record_type
        ORDER BY version_num DESC
        LIMIT 1
    );
END;
$$;


--
-- Name: get_version_history(uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_version_history(p_record_id uuid, p_record_type text) RETURNS TABLE(version_num integer, data jsonb, created_at timestamp with time zone, created_by text)
    LANGUAGE plpgsql
    AS $$ BEGIN RETURN QUERY
SELECT rv.version_num,
    rv.data,
    rv.created_at,
    rv.created_by
FROM record_version rv
WHERE rv.record_id = p_record_id
    AND rv.record_type = p_record_type
ORDER BY rv.version_num DESC;
END;
$$;


--
-- Name: location_coordinates_match(numeric, numeric, numeric, numeric, numeric); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.location_coordinates_match(lat1 numeric, lon1 numeric, lat2 numeric, lon2 numeric, tolerance numeric DEFAULT 0.0001) RETURNS boolean
    LANGUAGE plpgsql IMMUTABLE
    AS $$
BEGIN
    RETURN ABS(lat1 - lat2) < tolerance AND ABS(lon1 - lon2) < tolerance;
END;
$$;


--
-- Name: normalize_organization_name(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.normalize_organization_name(name text) RETURNS text
    LANGUAGE plpgsql IMMUTABLE
    AS $$
BEGIN
    -- Normalize organization names for consistent matching
    -- Remove extra whitespace, convert to lowercase, handle common variations
    RETURN LOWER(TRIM(REGEXP_REPLACE(name, '\s+', ' ', 'g')));
END;
$$;


--
-- Name: release_location_lock(bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.release_location_lock(lock_id bigint) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    PERFORM pg_advisory_unlock(lock_id);
END;
$$;


--
-- Name: release_organization_lock(bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.release_organization_lock(lock_id bigint) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    PERFORM pg_advisory_unlock(lock_id);
END;
$$;


--
-- Name: update_canonical_location(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_canonical_location() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN -- This is a placeholder for the merging logic
    -- In a real implementation, this would apply the merging strategy
    -- to update the canonical record based on all source records
    -- The MergeStrategy class will handle the actual merging of data
    -- We don't update any timestamp here since the location table doesn't have an updated_at column
    RETURN NEW;
END;
$$;


--
-- Name: update_organization_normalized_name(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_organization_normalized_name() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.normalized_name := normalize_organization_name(NEW.name);
    RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accessibility; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.accessibility (
    id character varying(250) NOT NULL,
    location_id character varying(250),
    description text,
    details text,
    url text
);


--
-- Name: COLUMN accessibility.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.accessibility.id IS 'The identifier for this accessibility information. Each entry must have a unique identifier.';


--
-- Name: COLUMN accessibility.location_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.accessibility.location_id IS 'The identifier for the location of the accessibility provision.';


--
-- Name: COLUMN accessibility.description; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.accessibility.description IS 'A free text description of the assistance or infrastructure that facilitates access to clients with disabilities.';


--
-- Name: COLUMN accessibility.details; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.accessibility.details IS 'Any further details relating to the relevant accessibility arrangements at this location.';


--
-- Name: COLUMN accessibility.url; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.accessibility.url IS 'The URL of a page giving more information about the accessibility of the location.';


--
-- Name: address; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.address (
    id character varying(250) NOT NULL,
    location_id character varying(250),
    attention text,
    address_1 text NOT NULL,
    address_2 text,
    city text NOT NULL,
    region text,
    state_province text NOT NULL,
    postal_code text NOT NULL,
    country text NOT NULL,
    address_type public.address_address_type_enum NOT NULL
);


--
-- Name: COLUMN address.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.address.id IS 'The identifier of the postal address. Each postal address must have a unique identifier.';


--
-- Name: COLUMN address.location_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.address.location_id IS 'The identifier of the location for this postal address.';


--
-- Name: COLUMN address.attention; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.address.attention IS 'The name of the person or entity whose attention should be sought at the location. These are often included as a "care of" component of an address.';


--
-- Name: COLUMN address.address_1; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.address.address_1 IS 'The first line(s) of the address, including office, building number and street.';


--
-- Name: COLUMN address.address_2; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.address.address_2 IS 'A second (additional) line of address information.';


--
-- Name: COLUMN address.city; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.address.city IS 'The city in which the address is located.';


--
-- Name: COLUMN address.region; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.address.region IS 'The region in which the address is located (optional).';


--
-- Name: COLUMN address.state_province; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.address.state_province IS 'The state or province in which the address is located.';


--
-- Name: COLUMN address.postal_code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.address.postal_code IS 'The postal code for the address.';


--
-- Name: COLUMN address.country; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.address.country IS 'The country in which the address is located. This should be given as an ISO 3361-1 country code (two letter abbreviation).';


--
-- Name: COLUMN address.address_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.address.address_type IS 'The type of address which may be `physical`, `postal`, or `virtual`.';


--
-- Name: attribute; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attribute (
    id character varying(250) NOT NULL,
    link_id text NOT NULL,
    taxonomy_term_id character varying(250) NOT NULL,
    link_type text,
    link_entity text NOT NULL,
    value text,
    label text
);


--
-- Name: COLUMN attribute.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.attribute.id IS 'The identifier of the attribute entry. Each attribute entry should have a unique identifier.';


--
-- Name: COLUMN attribute.link_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.attribute.link_id IS 'The identifier of the entity to which this taxonomy term applies.';


--
-- Name: COLUMN attribute.taxonomy_term_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.attribute.taxonomy_term_id IS 'The identifier of this taxonomy term from the taxonomy table.';


--
-- Name: COLUMN attribute.link_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.attribute.link_type IS 'A code taken from an enumerated open codelist to indicate what the taxonomy term describes, e.g. the service eligibility or intended audience.';


--
-- Name: COLUMN attribute.link_entity; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.attribute.link_entity IS 'The table of the Link Identifier.';


--
-- Name: COLUMN attribute.value; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.attribute.value IS 'The value (if any) of an attribute.';


--
-- Name: COLUMN attribute.label; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.attribute.label IS 'A free text label of the attribute.';


--
-- Name: contact; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contact (
    id character varying(250) NOT NULL,
    organization_id character varying(250),
    service_id character varying(250),
    service_at_location_id character varying(250),
    location_id character varying(250),
    name text,
    title text,
    department text,
    email text
);


--
-- Name: COLUMN contact.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.contact.id IS 'The identifier for the contact. Each contact must have a unique identifier.';


--
-- Name: COLUMN contact.organization_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.contact.organization_id IS 'The identifier of the organization for which this is a contact.';


--
-- Name: COLUMN contact.service_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.contact.service_id IS 'The identifier of the service for which this is a contact.';


--
-- Name: COLUMN contact.service_at_location_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.contact.service_at_location_id IS 'The identifier of the ‘service at location’ entry, when this contact is specific to a service in a particular location.';


--
-- Name: COLUMN contact.location_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.contact.location_id IS 'The identifier for the location of the contact.';


--
-- Name: COLUMN contact.name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.contact.name IS 'The name of the contact.';


--
-- Name: COLUMN contact.title; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.contact.title IS 'The job title of the contact.';


--
-- Name: COLUMN contact.department; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.contact.department IS 'The department that the contact is a part of.';


--
-- Name: COLUMN contact.email; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.contact.email IS 'The email address of the contact.';


--
-- Name: cost_option; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cost_option (
    id character varying(250) NOT NULL,
    service_id character varying(250) NOT NULL,
    valid_from date,
    valid_to date,
    option text,
    currency text,
    amount numeric,
    amount_description text
);


--
-- Name: COLUMN cost_option.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cost_option.id IS 'The identifier for the cost option. Each entry must have a unique identifier';


--
-- Name: COLUMN cost_option.service_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cost_option.service_id IS 'The identifier of the services for which the entry describes the cost.';


--
-- Name: COLUMN cost_option.valid_from; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cost_option.valid_from IS 'The date when this price is valid from.';


--
-- Name: COLUMN cost_option.valid_to; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cost_option.valid_to IS 'The date when this price is valid to.';


--
-- Name: COLUMN cost_option.option; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cost_option.option IS 'Conditions associated with the cost option.';


--
-- Name: COLUMN cost_option.currency; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cost_option.currency IS 'The 3 letter currency code of this cost option (expected to be gbp by Open Referral UK).';


--
-- Name: COLUMN cost_option.amount; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cost_option.amount IS 'The cost of the option, expressed as an amount.';


--
-- Name: COLUMN cost_option.amount_description; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cost_option.amount_description IS 'Specific details qualifying the cost amount.';


--
-- Name: funding; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.funding (
    id character varying(250) NOT NULL,
    organization_id character varying(250),
    service_id character varying(250),
    source text
);


--
-- Name: COLUMN funding.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.funding.id IS 'The identifier for the funding. Each entry must have a unique identifier.';


--
-- Name: COLUMN funding.organization_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.funding.organization_id IS 'The identifier of the organization in receipt of this funding.';


--
-- Name: COLUMN funding.service_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.funding.service_id IS 'The identifier of the service in receipt of this funding.';


--
-- Name: COLUMN funding.source; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.funding.source IS 'A free text description of the source of funds for this organization or service.';


--
-- Name: language; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.language (
    id character varying(250) NOT NULL,
    service_id character varying(250),
    location_id character varying(250),
    phone_id character varying(250),
    name text,
    code text,
    note text
);


--
-- Name: COLUMN language.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.language.id IS 'The identifier for the language. Each entry must have a unique identifier.';


--
-- Name: COLUMN language.service_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.language.service_id IS 'The identifier of the service for which the entry describes the languages in which services are delivered.';


--
-- Name: COLUMN language.location_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.language.location_id IS 'The identifier of the location for which the entry describes the languages in which services are delivered.';


--
-- Name: COLUMN language.phone_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.language.phone_id IS 'The identifier of the phone for which the entry describes the languages in which services delivered.';


--
-- Name: COLUMN language.name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.language.name IS 'The name of the language in which the service is delivered.';


--
-- Name: COLUMN language.code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.language.code IS 'The ISO 639-1 or ISO 639-3 code for the language.';


--
-- Name: COLUMN language.note; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.language.note IS 'A free text description of any additional context or services provided for this language.';


--
-- Name: location; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.location (
    id character varying(250) NOT NULL,
    location_type public.location_location_type_enum NOT NULL,
    url text,
    organization_id character varying(250),
    name text,
    alternate_name text,
    description text,
    transportation text,
    latitude numeric,
    longitude numeric,
    external_identifier text,
    external_identifier_type text,
    is_canonical boolean DEFAULT false,
    CONSTRAINT location_canonical_coordinates_check CHECK (((is_canonical = false) OR ((latitude IS NOT NULL) AND (longitude IS NOT NULL))))
);


--
-- Name: COLUMN location.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.location.id IS 'The identifier of the location. Each location must have a unique identifier.';


--
-- Name: COLUMN location.location_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.location.location_type IS 'The type of location, which may be either `physical`, `postal`, or `virtual`.';


--
-- Name: COLUMN location.url; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.location.url IS 'If location_type is virtual, then this field represents the URL of a virtual location.';


--
-- Name: COLUMN location.organization_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.location.organization_id IS 'The organization identifier for a location. This is the organization that is responsible for maintaining information about this location. The identifier of the organization should be given here. Details of the services the organization delivers at this location should be provided in the services_at_location table.';


--
-- Name: COLUMN location.name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.location.name IS 'The name of the location.';


--
-- Name: COLUMN location.alternate_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.location.alternate_name IS 'An (optional) alternative name of the location.';


--
-- Name: COLUMN location.description; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.location.description IS 'A free text description of the location.';


--
-- Name: COLUMN location.transportation; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.location.transportation IS 'A free text description of the access to public or private transportation to and from the location.';


--
-- Name: COLUMN location.latitude; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.location.latitude IS 'The latitude of the location expressed in decimal degrees in WGS84 datum.';


--
-- Name: COLUMN location.longitude; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.location.longitude IS 'The longitude of the location expressed in decimal degrees in WGS84 datum.';


--
-- Name: COLUMN location.external_identifier; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.location.external_identifier IS 'A third party identifier for the location, which can be drawn from other services e.g. UK UPRN.';


--
-- Name: COLUMN location.external_identifier_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.location.external_identifier_type IS 'The scheme used for the location''s external_identifier e.g. UK UPRN.';


--
-- Name: location_source; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.location_source (
    id character varying(250) NOT NULL,
    location_id character varying(250) NOT NULL,
    scraper_id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    latitude double precision NOT NULL,
    longitude double precision NOT NULL,
    location_type character varying(50) DEFAULT 'physical'::character varying,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: location_merged_view; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.location_merged_view AS
 SELECT l.id,
    l.name,
    l.description,
    l.latitude,
    l.longitude,
    l.location_type,
    json_object_agg(ls.scraper_id, json_build_object('id', ls.id, 'name', ls.name, 'description', ls.description, 'latitude', ls.latitude, 'longitude', ls.longitude)) AS source_data,
    json_object_agg('name',
        CASE
            WHEN (l.name = (ls.name)::text) THEN ls.scraper_id
            ELSE NULL::character varying
        END) FILTER (WHERE (l.name = (ls.name)::text)) AS field_sources
   FROM (public.location l
     JOIN public.location_source ls ON (((l.id)::text = (ls.location_id)::text)))
  WHERE (l.is_canonical = true)
  GROUP BY l.id, l.name, l.description, l.latitude, l.longitude, l.location_type;


--
-- Name: meta_table_description; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.meta_table_description (
    id character varying(250) NOT NULL,
    name text,
    language text,
    character_set text
);


--
-- Name: COLUMN meta_table_description.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.meta_table_description.id IS 'The identifier for the metadata description. Each entry must have a unique identifier.';


--
-- Name: COLUMN meta_table_description.name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.meta_table_description.name IS 'The name for the metadata description.';


--
-- Name: COLUMN meta_table_description.language; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.meta_table_description.language IS 'The ISO 639-1 or ISO 639-3 code for the language of the metadata description.';


--
-- Name: COLUMN meta_table_description.character_set; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.meta_table_description.character_set IS 'The character set of the metadata description.';


--
-- Name: metadata; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.metadata (
    id character varying(250) NOT NULL,
    resource_id text NOT NULL,
    resource_type text NOT NULL,
    last_action_date date NOT NULL,
    last_action_type text NOT NULL,
    field_name text NOT NULL,
    previous_value text NOT NULL,
    replacement_value text NOT NULL,
    updated_by text NOT NULL
);


--
-- Name: COLUMN metadata.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.metadata.id IS 'The identifier for this metadata. Each entry must have a unique identifier.';


--
-- Name: COLUMN metadata.resource_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.metadata.resource_id IS 'The identifier of the resource (service, program, location, address, or contact) that this metadata describes.';


--
-- Name: COLUMN metadata.resource_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.metadata.resource_type IS 'The type of entity being referenced.';


--
-- Name: COLUMN metadata.last_action_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.metadata.last_action_date IS 'The date when data was changed.';


--
-- Name: COLUMN metadata.last_action_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.metadata.last_action_type IS 'The kind of change made to the data.';


--
-- Name: COLUMN metadata.field_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.metadata.field_name IS 'The name of field that has been modified.';


--
-- Name: COLUMN metadata.previous_value; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.metadata.previous_value IS 'The previous value of the field that has been modified.';


--
-- Name: COLUMN metadata.replacement_value; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.metadata.replacement_value IS 'The new value of the field that has been modified.';


--
-- Name: COLUMN metadata.updated_by; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.metadata.updated_by IS 'The name of the person who modified the field.';


--
-- Name: organization; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.organization (
    id character varying(250) NOT NULL,
    name text NOT NULL,
    alternate_name text,
    description text NOT NULL,
    email text,
    website text,
    tax_status text,
    tax_id text,
    year_incorporated numeric,
    legal_status text,
    logo text,
    uri text,
    parent_organization_id text,
    normalized_name text NOT NULL
);


--
-- Name: COLUMN organization.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization.id IS 'The identifier for the organization. Each organization must have a unique identifier.';


--
-- Name: COLUMN organization.name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization.name IS 'The official or public name of the organization.';


--
-- Name: COLUMN organization.alternate_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization.alternate_name IS 'An (optional) alternative or commonly used name for the organization.';


--
-- Name: COLUMN organization.description; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization.description IS 'A free text description containing a brief summary about the organization. It can contain markup such as HTML or Markdown.';


--
-- Name: COLUMN organization.email; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization.email IS 'The contact e-mail address for the organization.';


--
-- Name: COLUMN organization.website; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization.website IS 'The URL (website address) of the organization.';


--
-- Name: COLUMN organization.tax_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization.tax_status IS 'DEPRECATED: Government assigned tax designation for tax-exempt organizations.';


--
-- Name: COLUMN organization.tax_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization.tax_id IS 'DEPRECATED: A government issued identifier used for the purpose of tax administration.';


--
-- Name: COLUMN organization.year_incorporated; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization.year_incorporated IS 'The year in which the organization was legally formed.';


--
-- Name: COLUMN organization.legal_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization.legal_status IS 'The legal conditions that an organization is operating under.';


--
-- Name: COLUMN organization.logo; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization.logo IS 'A URL to an image associated with the organization which can be presented alongside its name.';


--
-- Name: COLUMN organization.uri; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization.uri IS 'A persistent identifier to uniquely identify the organization such as those provided by Open Corporates or some other relevant URI provider. This is not for listing the website of the organization: that can be done through the website field of the Organization.';


--
-- Name: COLUMN organization.parent_organization_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization.parent_organization_id IS 'The identifier of the organization''s parent organization.';


--
-- Name: organization_identifier; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.organization_identifier (
    id character varying(250) NOT NULL,
    organization_id character varying(250) NOT NULL,
    identifier_scheme text,
    identifier_type text NOT NULL,
    identifier text NOT NULL
);


--
-- Name: COLUMN organization_identifier.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization_identifier.id IS 'The identifier for this organization identifier entry. Each entry must have a unique identifier.';


--
-- Name: COLUMN organization_identifier.organization_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization_identifier.organization_id IS 'The identifier of the organization. This should match the uuid of an organization object.';


--
-- Name: COLUMN organization_identifier.identifier_scheme; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization_identifier.identifier_scheme IS 'The scheme of the third party identifier, according to http://org-id.guide/.';


--
-- Name: COLUMN organization_identifier.identifier_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization_identifier.identifier_type IS 'A human-readable equivalent of the identifier_scheme. This may be used in cases where org-id.guide does not list an appropriate identifier scheme.';


--
-- Name: COLUMN organization_identifier.identifier; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.organization_identifier.identifier IS 'The third-party identifier value.';


--
-- Name: organization_source; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.organization_source (
    id character varying(250) NOT NULL,
    organization_id character varying(250) NOT NULL,
    scraper_id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    website character varying(255),
    email character varying(255),
    year_incorporated integer,
    legal_status character varying(50),
    tax_status character varying(50),
    tax_id character varying(50),
    uri character varying(255),
    parent_organization_id character varying(250),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: phone; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phone (
    id character varying(250) NOT NULL,
    location_id character varying(250),
    service_id character varying(250),
    organization_id character varying(250),
    contact_id character varying(250),
    service_at_location_id character varying(250),
    number text NOT NULL,
    extension numeric,
    type text,
    description text
);


--
-- Name: COLUMN phone.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.phone.id IS 'The identifier for the phone number. Each entry must have a unique identifier.';


--
-- Name: COLUMN phone.location_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.phone.location_id IS 'The identifier of the location where this phone number is located.';


--
-- Name: COLUMN phone.service_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.phone.service_id IS 'The identifier of the service for which this is the phone number.';


--
-- Name: COLUMN phone.organization_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.phone.organization_id IS 'The identifier of the organization for which this is the phone number.';


--
-- Name: COLUMN phone.contact_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.phone.contact_id IS 'The identifier of the contact for which this is the phone number.';


--
-- Name: COLUMN phone.service_at_location_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.phone.service_at_location_id IS 'The identifier of the ‘service at location’ table entry, when this phone number is specific to a service in a particular location.';


--
-- Name: COLUMN phone.number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.phone.number IS 'The phone number.';


--
-- Name: COLUMN phone.extension; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.phone.extension IS 'The extension of the phone number.';


--
-- Name: COLUMN phone.type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.phone.type IS 'Indicates the type of phone service, drawing from the RFC6350 list of types (text (for SMS), voice, fax, cell, video, pager, textphone).';


--
-- Name: COLUMN phone.description; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.phone.description IS 'A free text description providing extra information about the phone service';


--
-- Name: program; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.program (
    id character varying(250) NOT NULL,
    organization_id character varying(250) NOT NULL,
    name text NOT NULL,
    alternate_name text,
    description text NOT NULL
);


--
-- Name: COLUMN program.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.program.id IS 'The identifier for the program. Each program must have a unique identifier.';


--
-- Name: COLUMN program.organization_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.program.organization_id IS 'The identifier for the organization which the program belongs to. Each program must belong to a single organization, and the identifier for that organization should be given here.';


--
-- Name: COLUMN program.name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.program.name IS 'The name of the program.';


--
-- Name: COLUMN program.alternate_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.program.alternate_name IS 'The (optional) alternative name for the program.';


--
-- Name: COLUMN program.description; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.program.description IS 'A free text description of the program';


--
-- Name: reconciler_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reconciler_config (
    key character varying(100) NOT NULL,
    value text NOT NULL,
    description text,
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: reconciler_constraint_violations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reconciler_constraint_violations (
    id integer NOT NULL,
    constraint_name character varying(100) NOT NULL,
    table_name character varying(100) NOT NULL,
    operation character varying(20) NOT NULL,
    conflicting_data jsonb,
    resolved boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    resolved_at timestamp with time zone
);


--
-- Name: reconciler_constraint_violations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.reconciler_constraint_violations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: reconciler_constraint_violations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.reconciler_constraint_violations_id_seq OWNED BY public.reconciler_constraint_violations.id;


--
-- Name: record_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.record_version (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    record_id uuid NOT NULL,
    record_type text NOT NULL,
    version_num integer NOT NULL,
    data jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    created_by text,
    source_id character varying(250)
);


--
-- Name: TABLE record_version; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.record_version IS 'Tracks version history for HSDS records';


--
-- Name: COLUMN record_version.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.record_version.id IS 'Unique identifier for version record';


--
-- Name: COLUMN record_version.record_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.record_version.record_id IS 'ID of the HSDS record being versioned';


--
-- Name: COLUMN record_version.record_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.record_version.record_type IS 'Type of HSDS record (organization, service, location)';


--
-- Name: COLUMN record_version.version_num; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.record_version.version_num IS 'Sequential version number for this record';


--
-- Name: COLUMN record_version.data; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.record_version.data IS 'Complete record data at this version';


--
-- Name: COLUMN record_version.created_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.record_version.created_at IS 'When this version was created';


--
-- Name: COLUMN record_version.created_by; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.record_version.created_by IS 'What created this version';


--
-- Name: required_document; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.required_document (
    id character varying(250) NOT NULL,
    service_id character varying(250),
    document text,
    uri text
);


--
-- Name: COLUMN required_document.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.required_document.id IS 'The identifier for the document. Each document must have a unique identifier.';


--
-- Name: COLUMN required_document.service_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.required_document.service_id IS 'The identifier of the service for which this entry describes the required document.';


--
-- Name: COLUMN required_document.document; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.required_document.document IS 'A free text description of the document required to apply for or receive the service.';


--
-- Name: COLUMN required_document.uri; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.required_document.uri IS 'A web link to the document.';


--
-- Name: schedule; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.schedule (
    id character varying(250) NOT NULL,
    service_id character varying(250),
    location_id character varying(250),
    service_at_location_id character varying(250),
    valid_from date,
    valid_to date,
    dtstart date,
    timezone numeric,
    until date,
    count numeric,
    wkst public.schedule_wkst_enum,
    freq public.schedule_freq_enum,
    "interval" numeric,
    byday text,
    byweekno text,
    bymonthday text,
    byyearday text,
    description text,
    opens_at time without time zone,
    closes_at time without time zone,
    schedule_link text,
    attending_type text,
    notes text
);


--
-- Name: COLUMN schedule.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.schedule.id IS 'The identifier for the schedule. Each entry must have a unique identifier.';


--
-- Name: COLUMN schedule.service_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.schedule.service_id IS 'The identifier of the service for which this is the regular schedule';


--
-- Name: COLUMN schedule.location_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.schedule.location_id IS 'The identifier of the location for which this is the regular schedule';


--
-- Name: COLUMN schedule.service_at_location_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.schedule.service_at_location_id IS 'The identifier of the ‘service at location’ table entry, when this schedule is specific to a service in a particular location.';


--
-- Name: COLUMN schedule.valid_from; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.schedule.valid_from IS 'The date from which the schedule information is valid. It must be in the ISO 8601 format of YYYY-MM-DD,';


--
-- Name: COLUMN schedule.valid_to; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.schedule.valid_to IS 'The last date on which the schedule information is valid. It must be in the ISO 8601 format of YYYY-MM-DD.';


--
-- Name: COLUMN schedule.dtstart; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.schedule.dtstart IS 'iCal - The date of the first event is the schedule. Necessary when using the ‘interval’ feature, optional otherwise.';


--
-- Name: COLUMN schedule.timezone; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.schedule.timezone IS 'The timezone that all dates are expressed as, expressed as a UTC offset. Dates are assumed to be UTC otherwise.';


--
-- Name: COLUMN schedule.until; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.schedule.until IS 'iCal - The date of the last occurrence of the recurring event.';


--
-- Name: COLUMN schedule.count; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.schedule.count IS 'iCal - The number of times that the event occurs. Use this instead of ‘until’, if appropriate.';


--
-- Name: COLUMN schedule.wkst; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.schedule.wkst IS 'iCal - The two-letter code for the day on which the week starts: `MO`, `TU`, `WE`, `TH`, `FR`, `FR`, `SA`, `SU`';


--
-- Name: COLUMN schedule.freq; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.schedule.freq IS 'iCal - How often the frequency repeats. Values can be `WEEKLY` or `MONTHLY`';


--
-- Name: COLUMN schedule."interval"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.schedule."interval" IS 'iCal - How often the frequency repeats. For example, and Interval of 2 for a WEEKLY Frequency would represent fortnightly.';


--
-- Name: COLUMN schedule.byday; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.schedule.byday IS 'iCal - Comma separated days of the week. Where freq is MONTHLY each part can be preceded by a positive or negative integer to represent which occurrence in a month; e.g. 2MO is the second Monday in a month. -1FR is the last Friday';


--
-- Name: COLUMN schedule.byweekno; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.schedule.byweekno IS 'iCal - Comma separated numeric weeks of the year, where freq is WEEKLY. Can be negative to represent weeks before the end of the year; e.g. -5 is the 5th to last week in a year.';


--
-- Name: COLUMN schedule.bymonthday; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.schedule.bymonthday IS 'iCal - Comma separated numeric days of the month, where frequency is MONTHLY. Can be negative to represent days before the end of the month; e.g. -5 is the 5th to last day in a month.';


--
-- Name: COLUMN schedule.byyearday; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.schedule.byyearday IS 'iCal - Comma separated numeric days of the month, where frequency is YEARLY. Can be negative to represent days before the end of the year; e.g. -1 is the last day in a year.';


--
-- Name: COLUMN schedule.description; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.schedule.description IS 'A free text description of the availability of the service.';


--
-- Name: COLUMN schedule.opens_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.schedule.opens_at IS 'The time when a service or location opens. This should use HH:MM format and should include timezone information, either adding the suffix ‘Z’ when the date is in UTC, or including an offset from UTC (e.g. 09:00-05:00 for 9am EST.)';


--
-- Name: COLUMN schedule.closes_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.schedule.closes_at IS 'The time when a service or location closes. This should use HH:MM format and should include timezone information, either adding the suffix ‘Z’ when the date is in UTC, or including an offset from UTC (e.g. 09:00-05:00 for 9am EST.).';


--
-- Name: COLUMN schedule.schedule_link; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.schedule.schedule_link IS 'URL of a link for the schedule which may show each individual session and may provide a booking facility.';


--
-- Name: COLUMN schedule.attending_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.schedule.attending_type IS 'A free text description of how to attend this service.';


--
-- Name: COLUMN schedule.notes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.schedule.notes IS 'Free text notes on the schedule.';


--
-- Name: service; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service (
    id character varying(250) NOT NULL,
    organization_id character varying(250) NOT NULL,
    program_id character varying(250),
    name text NOT NULL,
    alternate_name text,
    description text,
    url text,
    email text,
    status public.service_status_enum NOT NULL,
    interpretation_services text,
    application_process text,
    fees_description text,
    wait_time text,
    fees text,
    accreditations text,
    eligibility_description text,
    minimum_age numeric,
    maximum_age numeric,
    assured_date date,
    assurer_email text,
    licenses text,
    alert text,
    last_modified timestamp without time zone
);


--
-- Name: COLUMN service.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service.id IS 'The identifier for the service. Each service must have a unique identifier.';


--
-- Name: COLUMN service.organization_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service.organization_id IS 'The identifier of the organization that provides this service.';


--
-- Name: COLUMN service.program_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service.program_id IS 'The identifier of the program this service is delivered under.';


--
-- Name: COLUMN service.name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service.name IS 'The official or public name of the service.';


--
-- Name: COLUMN service.alternate_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service.alternate_name IS 'An (optional) alternative name for this service.';


--
-- Name: COLUMN service.description; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service.description IS 'A free text description of the service.';


--
-- Name: COLUMN service.url; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service.url IS 'URL of the service';


--
-- Name: COLUMN service.email; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service.email IS 'An email address which can be used to contact the service provider.';


--
-- Name: COLUMN service.status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service.status IS 'The current status of the service which can be active, inactive, defunct, or temporarily closed.';


--
-- Name: COLUMN service.interpretation_services; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service.interpretation_services IS 'A free text description of any interpretation services available for accessing this service.';


--
-- Name: COLUMN service.application_process; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service.application_process IS 'A free text description of the steps needed to access this service.';


--
-- Name: COLUMN service.fees_description; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service.fees_description IS 'A free text description of any charges for service users to access this service.';


--
-- Name: COLUMN service.wait_time; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service.wait_time IS 'DEPRECATED: The time a client may expect to wait before receiving a service.';


--
-- Name: COLUMN service.fees; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service.fees IS 'DEPRECATED: Details of any charges for service users to access this service.';


--
-- Name: COLUMN service.accreditations; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service.accreditations IS 'A free text description of any accreditations. Accreditation is the formal evaluation of an organization or program against best practice standards set by an accrediting organization.';


--
-- Name: COLUMN service.eligibility_description; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service.eligibility_description IS 'A free text description of the type of person for whom this service is intended.';


--
-- Name: COLUMN service.minimum_age; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service.minimum_age IS 'The minimum age of a person required to meet this eligibility requirement.';


--
-- Name: COLUMN service.maximum_age; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service.maximum_age IS 'The maximum age of a person required to meet this eligibility requirement.';


--
-- Name: COLUMN service.assured_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service.assured_date IS 'The date that the information about the service was last checked.';


--
-- Name: COLUMN service.assurer_email; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service.assurer_email IS 'The contact e-mail address for the person or organization which last assured the service.';


--
-- Name: COLUMN service.licenses; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service.licenses IS 'DEPRECATED: An organization may have a license issued by a government entity to operate legally. A list of any such licenses can be provided here.';


--
-- Name: COLUMN service.alert; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service.alert IS 'A description of any short term alerts concerning the service.';


--
-- Name: COLUMN service.last_modified; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service.last_modified IS 'The datetime when the service, or any related information about the service, has changed. Should have millisecond accuracy.';


--
-- Name: service_area; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_area (
    id character varying(250) NOT NULL,
    service_id character varying(250),
    service_at_location_id character varying(250),
    name text,
    description text,
    extent text,
    extent_type text,
    uri text
);


--
-- Name: COLUMN service_area.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service_area.id IS 'The identifier for the service area. Each service area must have a unique identifier.';


--
-- Name: COLUMN service_area.service_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service_area.service_id IS 'The identifier of the service for which this entry describes the service area';


--
-- Name: COLUMN service_area.service_at_location_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service_area.service_at_location_id IS 'The identifier of the service at location object linked to this object.';


--
-- Name: COLUMN service_area.name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service_area.name IS 'A free text geographic area where a service is available.';


--
-- Name: COLUMN service_area.description; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service_area.description IS 'A more detailed free text description of this service area. Used to provide any additional information that cannot be communicated using the structured area and geometry fields.';


--
-- Name: COLUMN service_area.extent; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service_area.extent IS 'A definition of the polygon defining the area.';


--
-- Name: COLUMN service_area.extent_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service_area.extent_type IS 'The format of the extent field  populated from an enum of  "geojson", "topojson",  "kml",and (for legacy systems or early state during transformation) "text".';


--
-- Name: COLUMN service_area.uri; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service_area.uri IS 'A URI which acts as a persistent identifier to identify an area.';


--
-- Name: service_at_location; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_at_location (
    id character varying(250) NOT NULL,
    service_id character varying(250) NOT NULL,
    location_id character varying(250) NOT NULL,
    description text
);


--
-- Name: COLUMN service_at_location.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service_at_location.id IS 'The identifier of the service at location entry. Each entry must have a unique identifier.';


--
-- Name: COLUMN service_at_location.service_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service_at_location.service_id IS 'The identifier of the service at a given location.';


--
-- Name: COLUMN service_at_location.location_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service_at_location.location_id IS 'The identifier of the location where this service operates.';


--
-- Name: COLUMN service_at_location.description; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service_at_location.description IS 'A free text description of the service at this specific location.';


--
-- Name: service_capacity; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_capacity (
    id character varying(250) NOT NULL,
    service_id character varying(250) NOT NULL,
    unit_id character varying(250) NOT NULL,
    available numeric NOT NULL,
    maximum numeric,
    description text,
    updated timestamp without time zone NOT NULL
);


--
-- Name: COLUMN service_capacity.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service_capacity.id IS 'The identifier for the service_capacity object. Each service_capacity must have a unique identifier.';


--
-- Name: COLUMN service_capacity.service_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service_capacity.service_id IS 'The identifier for the Service object associated with this service capacity object. Only required in the tabular representation.';


--
-- Name: COLUMN service_capacity.unit_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service_capacity.unit_id IS 'The identifier for the unit object.';


--
-- Name: COLUMN service_capacity.available; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service_capacity.available IS 'The number of units available as of the last update.';


--
-- Name: COLUMN service_capacity.maximum; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service_capacity.maximum IS 'The maximum number of units that can be available for this service, if applicable';


--
-- Name: COLUMN service_capacity.description; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service_capacity.description IS 'A Human-Friendly description of this service capacity e.g. “Beds available for people experiencing homelessness”';


--
-- Name: COLUMN service_capacity.updated; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service_capacity.updated IS 'The datetime when this service_capacit y object was last updated or changed. Should have millisecond accuracy. ';


--
-- Name: service_source; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_source (
    id character varying(250) NOT NULL,
    service_id character varying(250) NOT NULL,
    scraper_id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    organization_id character varying(250),
    status character varying(50) DEFAULT 'active'::character varying,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: taxonomy; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.taxonomy (
    id character varying(250) NOT NULL,
    name text NOT NULL,
    description text NOT NULL,
    uri text,
    version text
);


--
-- Name: COLUMN taxonomy.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.taxonomy.id IS 'The identifier of the taxonomy. Each entry must have a unique identifier';


--
-- Name: COLUMN taxonomy.name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.taxonomy.name IS 'The name of the taxonomy from which terms are sourced.';


--
-- Name: COLUMN taxonomy.description; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.taxonomy.description IS 'A free text description of the taxonomy.';


--
-- Name: COLUMN taxonomy.uri; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.taxonomy.uri IS 'The URI of the taxonomy.';


--
-- Name: COLUMN taxonomy.version; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.taxonomy.version IS 'The version of the taxonomy.';


--
-- Name: taxonomy_term; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.taxonomy_term (
    id character varying(250) NOT NULL,
    code text,
    name text NOT NULL,
    description text NOT NULL,
    parent_id text,
    taxonomy text,
    language text,
    taxonomy_id character varying(250),
    term_uri text
);


--
-- Name: COLUMN taxonomy_term.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.taxonomy_term.id IS 'The identifier for this taxonomy term. Each taxonomy term must have a unique identifier, within the scope of the dataset.';


--
-- Name: COLUMN taxonomy_term.code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.taxonomy_term.code IS 'The term identfier as used in the taxonomy. This and the taxonomy_id combined define the term.';


--
-- Name: COLUMN taxonomy_term.name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.taxonomy_term.name IS 'The taxonomy term itself.';


--
-- Name: COLUMN taxonomy_term.description; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.taxonomy_term.description IS 'A free text description of the term.';


--
-- Name: COLUMN taxonomy_term.parent_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.taxonomy_term.parent_id IS 'If this is a child term in a hierarchical taxonomy, give the identifier of the parent category. For top-level categories, this is not required.';


--
-- Name: COLUMN taxonomy_term.taxonomy; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.taxonomy_term.taxonomy IS 'If this is an established taxonomy, a free text description of which taxonomy is in use. If possible, provide a URI.';


--
-- Name: COLUMN taxonomy_term.language; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.taxonomy_term.language IS 'An ISO 639-1, ISO 639-2, or ISO 639-3 [language code](http://www.loc.gov/standards/iso639-2/php/code_list.php) to represent the language of the term. The three-letter codes from ISO 639-2 and ISO 639-3 provide greater accuracy when describing variants of languages, which may be relevant to particular communities.';


--
-- Name: COLUMN taxonomy_term.taxonomy_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.taxonomy_term.taxonomy_id IS 'The identifier of the taxonomy containing the term.';


--
-- Name: COLUMN taxonomy_term.term_uri; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.taxonomy_term.term_uri IS 'URI of the term.';


--
-- Name: unit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.unit (
    id character varying(250) NOT NULL,
    name text NOT NULL,
    scheme text,
    identifier text,
    uri text
);


--
-- Name: COLUMN unit.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.unit.id IS 'The identifier for the unit object. Each unit must have a unique identifier.';


--
-- Name: COLUMN unit.name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.unit.name IS 'The human-readable name for this unit e.g. “Bed” or “Hours”';


--
-- Name: COLUMN unit.scheme; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.unit.scheme IS 'The scheme which formalizes the unit, if applicable e.g. “SI” for Standard International Units such as Kilogram, Litre, etc.';


--
-- Name: COLUMN unit.identifier; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.unit.identifier IS 'The identifier of the unit taken from the scheme if applicable e.g. `kgm` for Kilogram.';


--
-- Name: COLUMN unit.uri; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.unit.uri IS 'The URI to the definition of the unit, if applicable';


--
-- Name: url; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.url (
    id character varying(250) NOT NULL,
    label text,
    url text NOT NULL,
    organization_id character varying(250),
    service_id character varying(250)
);


--
-- Name: COLUMN url.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.url.id IS 'The identifier for the URL object. Each URL must have a unique identifier.';


--
-- Name: COLUMN url.label; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.url.label IS 'The human-readable label for this url e.g. “Twitter” or “Website”.';


--
-- Name: COLUMN url.url; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.url.url IS 'The URL for this URL object. This must be formatted as a valid URI.';


--
-- Name: COLUMN url.organization_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.url.organization_id IS 'The identifier for the organization associated with this URL object';


--
-- Name: COLUMN url.service_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.url.service_id IS 'The identifier for the service associated with this URL object';


--
-- Name: reconciler_constraint_violations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reconciler_constraint_violations ALTER COLUMN id SET DEFAULT nextval('public.reconciler_constraint_violations_id_seq'::regclass);


--
-- Data for Name: accessibility; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.accessibility (id, location_id, description, details, url) FROM stdin;
\.


--
-- Data for Name: address; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.address (id, location_id, attention, address_1, address_2, city, region, state_province, postal_code, country, address_type) FROM stdin;
\.


--
-- Data for Name: attribute; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attribute (id, link_id, taxonomy_term_id, link_type, link_entity, value, label) FROM stdin;
\.


--
-- Data for Name: contact; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contact (id, organization_id, service_id, service_at_location_id, location_id, name, title, department, email) FROM stdin;
\.


--
-- Data for Name: cost_option; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cost_option (id, service_id, valid_from, valid_to, option, currency, amount, amount_description) FROM stdin;
\.


--
-- Data for Name: funding; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.funding (id, organization_id, service_id, source) FROM stdin;
\.


--
-- Data for Name: language; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.language (id, service_id, location_id, phone_id, name, code, note) FROM stdin;
\.


--
-- Data for Name: location; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.location (id, location_type, url, organization_id, name, alternate_name, description, transportation, latitude, longitude, external_identifier, external_identifier_type, is_canonical) FROM stdin;
\.


--
-- Data for Name: location_source; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.location_source (id, location_id, scraper_id, name, description, latitude, longitude, location_type, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: meta_table_description; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.meta_table_description (id, name, language, character_set) FROM stdin;
\.


--
-- Data for Name: metadata; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.metadata (id, resource_id, resource_type, last_action_date, last_action_type, field_name, previous_value, replacement_value, updated_by) FROM stdin;
\.


--
-- Data for Name: organization; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.organization (id, name, alternate_name, description, email, website, tax_status, tax_id, year_incorporated, legal_status, logo, uri, parent_organization_id, normalized_name) FROM stdin;
\.


--
-- Data for Name: organization_identifier; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.organization_identifier (id, organization_id, identifier_scheme, identifier_type, identifier) FROM stdin;
\.


--
-- Data for Name: organization_source; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.organization_source (id, organization_id, scraper_id, name, description, website, email, year_incorporated, legal_status, tax_status, tax_id, uri, parent_organization_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: phone; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phone (id, location_id, service_id, organization_id, contact_id, service_at_location_id, number, extension, type, description) FROM stdin;
\.


--
-- Data for Name: program; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.program (id, organization_id, name, alternate_name, description) FROM stdin;
\.


--
-- Data for Name: reconciler_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reconciler_config (key, value, description, updated_at) FROM stdin;
max_retry_attempts	3	Maximum number of retry attempts for constraint violations	2025-07-27 22:27:32.226972+00
retry_base_delay_ms	100	Base delay in milliseconds between retries	2025-07-27 22:27:32.226972+00
retry_backoff_multiplier	2.0	Exponential backoff multiplier for retries	2025-07-27 22:27:32.226972+00
location_tolerance	0.0001	Default coordinate tolerance for location matching (≈11m)	2025-07-27 22:27:32.226972+00
\.


--
-- Data for Name: reconciler_constraint_violations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reconciler_constraint_violations (id, constraint_name, table_name, operation, conflicting_data, resolved, created_at, resolved_at) FROM stdin;
\.


--
-- Data for Name: record_version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.record_version (id, record_id, record_type, version_num, data, created_at, created_by, source_id) FROM stdin;
\.


--
-- Data for Name: required_document; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.required_document (id, service_id, document, uri) FROM stdin;
\.


--
-- Data for Name: schedule; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.schedule (id, service_id, location_id, service_at_location_id, valid_from, valid_to, dtstart, timezone, until, count, wkst, freq, "interval", byday, byweekno, bymonthday, byyearday, description, opens_at, closes_at, schedule_link, attending_type, notes) FROM stdin;
\.


--
-- Data for Name: service; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.service (id, organization_id, program_id, name, alternate_name, description, url, email, status, interpretation_services, application_process, fees_description, wait_time, fees, accreditations, eligibility_description, minimum_age, maximum_age, assured_date, assurer_email, licenses, alert, last_modified) FROM stdin;
\.


--
-- Data for Name: service_area; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.service_area (id, service_id, service_at_location_id, name, description, extent, extent_type, uri) FROM stdin;
\.


--
-- Data for Name: service_at_location; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.service_at_location (id, service_id, location_id, description) FROM stdin;
\.


--
-- Data for Name: service_capacity; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.service_capacity (id, service_id, unit_id, available, maximum, description, updated) FROM stdin;
\.


--
-- Data for Name: service_source; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.service_source (id, service_id, scraper_id, name, description, organization_id, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM stdin;
\.


--
-- Data for Name: taxonomy; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.taxonomy (id, name, description, uri, version) FROM stdin;
\.


--
-- Data for Name: taxonomy_term; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.taxonomy_term (id, code, name, description, parent_id, taxonomy, language, taxonomy_id, term_uri) FROM stdin;
\.


--
-- Data for Name: unit; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.unit (id, name, scheme, identifier, uri) FROM stdin;
\.


--
-- Data for Name: url; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.url (id, label, url, organization_id, service_id) FROM stdin;
\.


--
-- Name: reconciler_constraint_violations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.reconciler_constraint_violations_id_seq', 1, false);


--
-- Name: accessibility accessibility_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accessibility
    ADD CONSTRAINT accessibility_pkey PRIMARY KEY (id);


--
-- Name: address address_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.address
    ADD CONSTRAINT address_pkey PRIMARY KEY (id);


--
-- Name: attribute attribute_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attribute
    ADD CONSTRAINT attribute_pkey PRIMARY KEY (id);


--
-- Name: contact contact_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contact
    ADD CONSTRAINT contact_pkey PRIMARY KEY (id);


--
-- Name: cost_option cost_option_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_option
    ADD CONSTRAINT cost_option_pkey PRIMARY KEY (id);


--
-- Name: funding funding_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.funding
    ADD CONSTRAINT funding_pkey PRIMARY KEY (id);


--
-- Name: language language_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.language
    ADD CONSTRAINT language_pkey PRIMARY KEY (id);


--
-- Name: location location_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location
    ADD CONSTRAINT location_pkey PRIMARY KEY (id);


--
-- Name: location_source location_source_location_id_scraper_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_source
    ADD CONSTRAINT location_source_location_id_scraper_id_key UNIQUE (location_id, scraper_id);


--
-- Name: location_source location_source_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_source
    ADD CONSTRAINT location_source_pkey PRIMARY KEY (id);


--
-- Name: meta_table_description meta_table_description_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meta_table_description
    ADD CONSTRAINT meta_table_description_pkey PRIMARY KEY (id);


--
-- Name: metadata metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.metadata
    ADD CONSTRAINT metadata_pkey PRIMARY KEY (id);


--
-- Name: organization_identifier organization_identifier_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_identifier
    ADD CONSTRAINT organization_identifier_pkey PRIMARY KEY (id);


--
-- Name: organization organization_normalized_name_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization
    ADD CONSTRAINT organization_normalized_name_unique UNIQUE (normalized_name);


--
-- Name: organization organization_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization
    ADD CONSTRAINT organization_pkey PRIMARY KEY (id);


--
-- Name: organization_source organization_source_organization_id_scraper_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_source
    ADD CONSTRAINT organization_source_organization_id_scraper_id_key UNIQUE (organization_id, scraper_id);


--
-- Name: organization_source organization_source_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_source
    ADD CONSTRAINT organization_source_pkey PRIMARY KEY (id);


--
-- Name: phone phone_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phone
    ADD CONSTRAINT phone_pkey PRIMARY KEY (id);


--
-- Name: program program_organization_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program
    ADD CONSTRAINT program_organization_id_key UNIQUE (organization_id);


--
-- Name: program program_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program
    ADD CONSTRAINT program_pkey PRIMARY KEY (id);


--
-- Name: reconciler_config reconciler_config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reconciler_config
    ADD CONSTRAINT reconciler_config_pkey PRIMARY KEY (key);


--
-- Name: reconciler_constraint_violations reconciler_constraint_violations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reconciler_constraint_violations
    ADD CONSTRAINT reconciler_constraint_violations_pkey PRIMARY KEY (id);


--
-- Name: record_version record_version_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.record_version
    ADD CONSTRAINT record_version_pkey PRIMARY KEY (id);


--
-- Name: record_version record_version_record_id_version_num_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.record_version
    ADD CONSTRAINT record_version_record_id_version_num_key UNIQUE (record_id, version_num);


--
-- Name: required_document required_document_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.required_document
    ADD CONSTRAINT required_document_pkey PRIMARY KEY (id);


--
-- Name: schedule schedule_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schedule
    ADD CONSTRAINT schedule_pkey PRIMARY KEY (id);


--
-- Name: service_area service_area_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_area
    ADD CONSTRAINT service_area_pkey PRIMARY KEY (id);


--
-- Name: service_at_location service_at_location_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_at_location
    ADD CONSTRAINT service_at_location_pkey PRIMARY KEY (id);


--
-- Name: service_capacity service_capacity_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_capacity
    ADD CONSTRAINT service_capacity_pkey PRIMARY KEY (id);


--
-- Name: service service_name_organization_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service
    ADD CONSTRAINT service_name_organization_unique UNIQUE (name, organization_id);


--
-- Name: service service_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service
    ADD CONSTRAINT service_pkey PRIMARY KEY (id);


--
-- Name: service_source service_source_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_source
    ADD CONSTRAINT service_source_pkey PRIMARY KEY (id);


--
-- Name: service_source service_source_service_id_scraper_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_source
    ADD CONSTRAINT service_source_service_id_scraper_id_key UNIQUE (service_id, scraper_id);


--
-- Name: taxonomy taxonomy_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taxonomy
    ADD CONSTRAINT taxonomy_pkey PRIMARY KEY (id);


--
-- Name: taxonomy_term taxonomy_term_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taxonomy_term
    ADD CONSTRAINT taxonomy_term_code_key UNIQUE (code);


--
-- Name: taxonomy_term taxonomy_term_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taxonomy_term
    ADD CONSTRAINT taxonomy_term_pkey PRIMARY KEY (id);


--
-- Name: unit unit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unit
    ADD CONSTRAINT unit_pkey PRIMARY KEY (id);


--
-- Name: url url_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.url
    ADD CONSTRAINT url_pkey PRIMARY KEY (id);


--
-- Name: idx_location_coords; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_location_coords ON public.location USING gist (public.st_setsrid(public.st_makepoint((longitude)::double precision, (latitude)::double precision), 4326));


--
-- Name: idx_record_version_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_record_version_created ON public.record_version USING btree (created_at);


--
-- Name: idx_record_version_record; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_record_version_record ON public.record_version USING btree (record_id);


--
-- Name: idx_record_version_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_record_version_type ON public.record_version USING btree (record_type);


--
-- Name: location_coordinates_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX location_coordinates_idx ON public.location USING gist (point((longitude)::double precision, (latitude)::double precision));


--
-- Name: location_source_location_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX location_source_location_id_idx ON public.location_source USING btree (location_id);


--
-- Name: location_source_location_scraper_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX location_source_location_scraper_idx ON public.location_source USING btree (location_id, scraper_id);


--
-- Name: location_source_scraper_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX location_source_scraper_id_idx ON public.location_source USING btree (scraper_id);


--
-- Name: organization_normalized_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX organization_normalized_name_idx ON public.organization USING btree (normalized_name);


--
-- Name: organization_source_org_scraper_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX organization_source_org_scraper_idx ON public.organization_source USING btree (organization_id, scraper_id);


--
-- Name: organization_source_organization_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX organization_source_organization_id_idx ON public.organization_source USING btree (organization_id);


--
-- Name: organization_source_scraper_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX organization_source_scraper_id_idx ON public.organization_source USING btree (scraper_id);


--
-- Name: reconciler_violations_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX reconciler_violations_created_at_idx ON public.reconciler_constraint_violations USING btree (created_at);


--
-- Name: reconciler_violations_resolved_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX reconciler_violations_resolved_idx ON public.reconciler_constraint_violations USING btree (resolved, created_at);


--
-- Name: record_version_source_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX record_version_source_id_idx ON public.record_version USING btree (source_id);


--
-- Name: service_name_organization_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX service_name_organization_idx ON public.service USING btree (name, organization_id);


--
-- Name: service_organization_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX service_organization_id_idx ON public.service USING btree (organization_id) WHERE (organization_id IS NOT NULL);


--
-- Name: service_source_scraper_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX service_source_scraper_id_idx ON public.service_source USING btree (scraper_id);


--
-- Name: service_source_service_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX service_source_service_id_idx ON public.service_source USING btree (service_id);


--
-- Name: service_source_service_scraper_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX service_source_service_scraper_idx ON public.service_source USING btree (service_id, scraper_id);


--
-- Name: organization organization_normalize_name_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER organization_normalize_name_trigger BEFORE INSERT OR UPDATE OF name ON public.organization FOR EACH ROW EXECUTE FUNCTION public.update_organization_normalized_name();


--
-- Name: location_source update_canonical_location_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_canonical_location_trigger AFTER INSERT OR UPDATE ON public.location_source FOR EACH ROW EXECUTE FUNCTION public.update_canonical_location();


--
-- Name: accessibility accessibility_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accessibility
    ADD CONSTRAINT accessibility_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.location(id);


--
-- Name: address address_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.address
    ADD CONSTRAINT address_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.location(id);


--
-- Name: attribute attribute_taxonomy_term_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attribute
    ADD CONSTRAINT attribute_taxonomy_term_id_fkey FOREIGN KEY (taxonomy_term_id) REFERENCES public.taxonomy_term(id);


--
-- Name: contact contact_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contact
    ADD CONSTRAINT contact_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.location(id);


--
-- Name: contact contact_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contact
    ADD CONSTRAINT contact_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organization(id);


--
-- Name: contact contact_service_at_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contact
    ADD CONSTRAINT contact_service_at_location_id_fkey FOREIGN KEY (service_at_location_id) REFERENCES public.service_at_location(id);


--
-- Name: contact contact_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contact
    ADD CONSTRAINT contact_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.service(id);


--
-- Name: cost_option cost_option_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_option
    ADD CONSTRAINT cost_option_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.service(id);


--
-- Name: funding funding_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.funding
    ADD CONSTRAINT funding_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organization(id);


--
-- Name: funding funding_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.funding
    ADD CONSTRAINT funding_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.service(id);


--
-- Name: language language_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.language
    ADD CONSTRAINT language_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.location(id);


--
-- Name: language language_phone_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.language
    ADD CONSTRAINT language_phone_id_fkey FOREIGN KEY (phone_id) REFERENCES public.phone(id);


--
-- Name: language language_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.language
    ADD CONSTRAINT language_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.service(id);


--
-- Name: location location_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location
    ADD CONSTRAINT location_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organization(id);


--
-- Name: location_source location_source_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_source
    ADD CONSTRAINT location_source_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.location(id);


--
-- Name: organization_identifier organization_identifier_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_identifier
    ADD CONSTRAINT organization_identifier_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organization(id);


--
-- Name: organization_source organization_source_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_source
    ADD CONSTRAINT organization_source_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organization(id);


--
-- Name: organization_source organization_source_parent_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_source
    ADD CONSTRAINT organization_source_parent_organization_id_fkey FOREIGN KEY (parent_organization_id) REFERENCES public.organization(id);


--
-- Name: phone phone_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phone
    ADD CONSTRAINT phone_contact_id_fkey FOREIGN KEY (contact_id) REFERENCES public.contact(id);


--
-- Name: phone phone_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phone
    ADD CONSTRAINT phone_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.location(id);


--
-- Name: phone phone_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phone
    ADD CONSTRAINT phone_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organization(id);


--
-- Name: phone phone_service_at_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phone
    ADD CONSTRAINT phone_service_at_location_id_fkey FOREIGN KEY (service_at_location_id) REFERENCES public.service_at_location(id);


--
-- Name: phone phone_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phone
    ADD CONSTRAINT phone_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.service(id);


--
-- Name: program program_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program
    ADD CONSTRAINT program_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organization(id);


--
-- Name: required_document required_document_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.required_document
    ADD CONSTRAINT required_document_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.service(id);


--
-- Name: schedule schedule_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schedule
    ADD CONSTRAINT schedule_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.location(id);


--
-- Name: schedule schedule_service_at_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schedule
    ADD CONSTRAINT schedule_service_at_location_id_fkey FOREIGN KEY (service_at_location_id) REFERENCES public.service_at_location(id);


--
-- Name: schedule schedule_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schedule
    ADD CONSTRAINT schedule_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.service(id);


--
-- Name: service_area service_area_service_at_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_area
    ADD CONSTRAINT service_area_service_at_location_id_fkey FOREIGN KEY (service_at_location_id) REFERENCES public.service_at_location(id);


--
-- Name: service_area service_area_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_area
    ADD CONSTRAINT service_area_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.service(id);


--
-- Name: service_at_location service_at_location_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_at_location
    ADD CONSTRAINT service_at_location_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.location(id);


--
-- Name: service_at_location service_at_location_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_at_location
    ADD CONSTRAINT service_at_location_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.service(id);


--
-- Name: service_capacity service_capacity_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_capacity
    ADD CONSTRAINT service_capacity_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.service(id);


--
-- Name: service_capacity service_capacity_unit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_capacity
    ADD CONSTRAINT service_capacity_unit_id_fkey FOREIGN KEY (unit_id) REFERENCES public.unit(id);


--
-- Name: service service_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service
    ADD CONSTRAINT service_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organization(id);


--
-- Name: service service_program_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service
    ADD CONSTRAINT service_program_id_fkey FOREIGN KEY (program_id) REFERENCES public.program(id);


--
-- Name: service_source service_source_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_source
    ADD CONSTRAINT service_source_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organization(id);


--
-- Name: service_source service_source_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_source
    ADD CONSTRAINT service_source_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.service(id);


--
-- Name: taxonomy_term taxonomy_term_taxonomy_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taxonomy_term
    ADD CONSTRAINT taxonomy_term_taxonomy_id_fkey FOREIGN KEY (taxonomy_id) REFERENCES public.taxonomy(id);


--
-- Name: url url_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.url
    ADD CONSTRAINT url_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organization(id);


--
-- Name: url url_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.url
    ADD CONSTRAINT url_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.service(id);


--
-- PostgreSQL database dump complete
--

